#ifndef _GAME_H
#define _GAME_H

void playGame();

#endif