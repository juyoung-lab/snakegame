#ifndef __JOYSTICK_H
#define __JOYSTICK_H

//#include "constants.h"

int readJoystick();

#endif