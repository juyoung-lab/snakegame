#ifndef _MAIN_H
#define _MAIN_H

int main();

#endif